// Aquí se programarán los comandos básicos y razonamiento de Foxy.
