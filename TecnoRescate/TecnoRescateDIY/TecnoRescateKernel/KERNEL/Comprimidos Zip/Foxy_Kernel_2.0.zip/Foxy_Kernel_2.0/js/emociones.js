// Aquí se programarán las emociones y reacciones de Foxy.
