>@The_daredevil@

/NIP02_PlacaBase/
MAPEO DE PINES - PLACA BASE NIP02&090_M V5
MÓDULO FÍSICO PRINCIPAL – FOXYCORE_01
NIP02_PlacaBase.txt

---------*---------+---------*-----------

RT5350F_CamIP
Microsoft.Management.Deployment
MÓDULO DE HARDWARE – FOXY
PuTTY Installer (instalado)
_________________@________@______________

> Fin:-